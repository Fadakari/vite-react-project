from django.apps import AppConfig

class QaConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'apps.qa'
    verbose_name = 'مدیریت سوال و جواب و مشاوره'
